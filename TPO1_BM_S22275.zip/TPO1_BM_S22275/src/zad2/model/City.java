package zad2.model;

public class City {
    Double lat;
    Double lon;
    public City( Double lat, Double lon) {
        this.lat = lat;
        this.lon = lon;
    }
    public Double getLat() {
        return lat;
    }
    public Double getLon() {
        return lon;
    }
}
