package zad1;

public class Futil {
    public static void processDir(String dirName, String resultFileName) {
    }
}
